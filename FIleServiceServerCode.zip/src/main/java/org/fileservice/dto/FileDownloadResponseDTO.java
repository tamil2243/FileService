package org.fileservice.dto;

public class FileDownloadResponseDTO extends ResponseDTO{
    
    


    public FileDownloadResponseDTO() {
    }


    public FileDownloadResponseDTO(boolean status, String message){
        super(status,message);
    }
    
    
}
