package org.fileservice.dto;

public class ChangePasswordResponseDTO extends ResponseDTO{


    public ChangePasswordResponseDTO(){}

    public ChangePasswordResponseDTO(boolean status, String message){
        super(status,message);
    }
    
    
}
