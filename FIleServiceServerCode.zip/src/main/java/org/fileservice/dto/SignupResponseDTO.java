package org.fileservice.dto;

public class SignupResponseDTO extends ResponseDTO{


  


    public SignupResponseDTO() {
    }


    public SignupResponseDTO(boolean status, String message){
        super(status,message);
    }
    
}
