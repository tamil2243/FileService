package org.fileservice.Exception;

public class UserNotFountException extends RuntimeException {

    public UserNotFountException(String message){
        super(message);

    }
    
}
