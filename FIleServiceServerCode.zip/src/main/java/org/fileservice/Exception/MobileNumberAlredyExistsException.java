package org.fileservice.Exception;

public class MobileNumberAlredyExistsException extends RuntimeException{

    public MobileNumberAlredyExistsException(String message){
        super(message);
    }
    
}
