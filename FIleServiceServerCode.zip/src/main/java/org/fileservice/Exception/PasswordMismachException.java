package org.fileservice.Exception;

public class PasswordMismachException extends RuntimeException{

    public PasswordMismachException(String message){
        super(message);
    }
    
}
