package org.fileservice.Exception;

public class EmailAlredyExistsException extends RuntimeException{


    public EmailAlredyExistsException(String message){
        super(message);
    }
    
}
