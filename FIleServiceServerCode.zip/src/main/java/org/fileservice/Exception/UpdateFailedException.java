package org.fileservice.Exception;

public class UpdateFailedException extends RuntimeException{

    public UpdateFailedException(String message){
        super(message);
    }
    
}
